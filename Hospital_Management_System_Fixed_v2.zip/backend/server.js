import express from 'express';
import cors from 'cors';

const app=express();
app.use(cors());
app.use(express.json());

const patients=[
 {id:'P-1001',name:'Aarav Sharma',age:32,gender:'Male',condition:'Fever'},
 {id:'P-1002',name:'Priya Verma',age:27,gender:'Female',condition:'Migraine'},
 {id:'P-1003',name:'Rahul Gupta',age:54,gender:'Male',condition:'Diabetes'}
];

const doctors=[
 {id:'D-101',name:'Dr. Neha Kapoor',specialization:'Cardiologist',department:'Cardiology'},
 {id:'D-102',name:'Dr. Arjun Malhotra',specialization:'Neurologist',department:'Neurology'}
];

const appointments=[
 {id:'APT-501',patientId:'P-1001',doctorId:'D-101',date:'2026-08-30',time:'10:00',status:'Confirmed'}
];

app.get('/api/health',(req,res)=>res.json({status:'ok',message:'Hospital Management API is running'}));
app.get('/api/patients',(req,res)=>res.json(patients));
app.post('/api/patients',(req,res)=>{const p={id:'P-'+Date.now(),...req.body};patients.push(p);res.status(201).json(p)});
app.get('/api/doctors',(req,res)=>res.json(doctors));
app.get('/api/appointments',(req,res)=>res.json(appointments));
app.get('/api/dashboard',(req,res)=>res.json({patients:1284,doctors:86,appointments:326,revenue:842000}));

const PORT=5000;
app.listen(PORT,()=>console.log(`Hospital API running at http://localhost:${PORT}`));
